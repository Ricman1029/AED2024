from funciones import determinar_control, validacion_envios, obtener_codigo_postal, obtener_direccion,obtener_forma_pago, obtener_tipo_envio, country, final_amount
from entidades import Envio

def menu():
    print("1. Limpiar y cargar envíos")
    print("2. Cargar por teclado el envío")
    print("3. Mostrar envíos")
    print("4. Buscar dirección y tipo de envío")
    print("5. Buscar por código postal")
    print("6. Cantidad de envíos (HC o SC)")
    print("7. Importe final acumulado por tipo de envío")
    print("8. Mayor importe final por tipo de envío")
    print("9. Promedio y envíos menores al promedio")
    print("10. Salir")
    
def ejecutar_opcion(opcion, lista, control, vector):
    if opcion == "1":
        control = limpiar_cargar_envios(lista)
    elif opcion == "2":
        cargar_teclado_envio(lista)
    elif opcion == "3":
        mostrar_envios(lista)
    elif opcion == "4":
        buscar_direccion_tipo(lista)
    elif opcion == "5":
        buscar_por_codigo_postal(lista)
    elif opcion == "6":
        cantidad_de_envios_HC_SC(lista, control)
    elif opcion == "7":
        vector = importe_final_acumulado(lista, control)
    elif opcion == "8":
        mayor_importe_final(vector)
    elif opcion == "9":
        promedio_envios_menores(vector)
    elif opcion == "10":
        salir()
    return control, vector

def mostrar_cantidad_tipo(vector):
    for i in range (len(vector)):
        print (f"El envio de tipo {i} tiene {vector[i]} direcciones validas")
        
def mostrar_acumulado_envio(vector):
    for i in range (len(vector)):
        print(f"El acumulado del tipo de envío {i} es: {vector[i]}.")
        
def imprimir_datos (lista, cantidad): 
    for i in range (0, cantidad): 
        pais = country(lista[i].codigo_postal)
        print(lista[i], pais)

def cantidad_datos(lista):
    datos = int(input("Ingrese la cantidad de datos que desea ver. (0 para ver TODOS): "))
    if datos == 0:
        largo = len(lista)
        return largo
    else:
        return datos
                       
def opcion_borrar():
    opcion = input("¿Desea borrar todos los datos? Ingrese si o no: ")
    if opcion.lower() == "si":
        return True
    return False     

def leer_archivo(archivo, lista):
    linea = archivo.readline()
    while linea != "":
        codigo_postal = obtener_codigo_postal(linea)
        direccion = obtener_direccion(linea)
        tipo_envio = int(obtener_tipo_envio(linea))
        forma_pago = int(obtener_forma_pago(linea))
        envio = Envio(codigo_postal, direccion, tipo_envio, forma_pago)
        lista.append(envio)
        linea = archivo.readline()
    
def limpiar_cargar_envios(lista):
    print("Limpiar y cargar envíos")
    opcion = opcion_borrar()
    if opcion == True:
        lista[0:-1] = []
        with open ("envios-tp3.txt" , "r") as archivo:
          linea = archivo.readline()
          control = determinar_control(linea)
          leer_archivo(archivo, lista)
    return control
            
def ingresar_tipo ():
    tipo = (input('Tipo de envio (0-6): '))
    while tipo not in ("0","1","2","3","4","5","6"):
        tipo = (input('Ingresar un número de tipo válido: '))
    return int(tipo) 

def ingresar_pago ():
    forma_pago = input('Forma de pago (1,2): ')
    while forma_pago not in ("1","2"):
        forma_pago = input('Ingrese un numero de pago válido: ')
    return int(forma_pago)

def selection_sort(lista):
    largo = len(lista)
    for i in range(largo-1):
        for j in range(i+1, largo):
            if lista[i].codigo_postal > lista[j].codigo_postal:
                lista[i], lista[j] = lista[j], lista[i]

def cargar_teclado_envio(lista):
    print("Cargar por teclado el envío")
    codigo_postal = input('Codigo postal: ')
    direccion = input('Direccion: ')
    tipo = ingresar_tipo()
    forma_pago = ingresar_pago()
    print()
    lista.append (Envio (codigo_postal, direccion, tipo, forma_pago))
    
def mostrar_envios(lista): #punto 3
    print("Mostrar envíos")
    selection_sort(lista)
    primeros_numeros = cantidad_datos(lista)
    imprimir_datos(lista, primeros_numeros)
    
def buscar_direccion_tipo(lista):
    print("Buscar dirección y tipo de envío")
    direccion = input("Ingresa la dirección: ")
    tipo_envio = int(input("Ingresa el tipo de envio: "))

    for i in range (len(lista)):
        if direccion == lista[i].direccion and tipo_envio == lista[i].tipo:
            print(lista[i])
            return
    print ("No se encontro ninguna coincidencia.") 

def buscar_por_codigo_postal(lista):
    print("Buscar por código postal")
    codigo_postal = input("Ingresa un codigo postal: ")

    for i in range (len(lista)):
        if codigo_postal == lista[i].codigo_postal:
            if lista[i].forma_pago == 1:
               lista[i].forma_pago = 2
            else:
               lista[i].forma_pago = 1
            print(lista[i])
            return
    print("No se encontro ninguna coincidencia.")

def cantidad_de_envios_HC_SC(lista, control):
    print("Cantidad de envíos (HC o SC)")
    vector = [0,0,0,0,0,0,0]

    if control == "Soft Control":
        for i in range (len(lista)):
            vector[lista[i].tipo] += 1
        print ("Este archivo es Soft Control")

    elif control == "Hard Control":
        for i in range (len(lista)):
            if validacion_envios(lista[i].direccion):
                vector[lista[i].tipo] += 1 
        print ("Este archivo es Hard Control")
        
    mostrar_cantidad_tipo(vector)
            
def importe_final_acumulado(lista, control):
    print("Importe final acumulado por tipo de envío")
    vector = [0,0,0,0,0,0,0]
    
    if control == "Soft Control":
        for i in range (len(lista)):
            destino = country(lista[i].codigo_postal)
            importe_final = final_amount(lista[i].codigo_postal, destino, lista[i].tipo, lista[i].forma_pago)
            vector[lista[i].tipo] += importe_final
                        
    if control == "Hard Control":
        for i in range (len(lista)):
            if validacion_envios(lista[i].direccion):
                destino = country(lista[i].codigo_postal)
                importe_final = final_amount(lista[i].codigo_postal, destino, lista[i].tipo, lista[i].forma_pago)
                vector[lista[i].tipo] += importe_final
                
    mostrar_acumulado_envio(vector)
    return vector

def mayor_importe_final(vector):
    print("Mayor importe final por tipo de envío")
    mayor = total = 0
    if vector == None:
        print("Error")
        return    
    
    for i in range (len(vector)):
        if vector[i] > mayor:
            mayor = vector[i]
            posicion = i   
        total += vector[i]   
    porcentaje = mayor * 100 // total
    print (f"El mayor importe acumulado es: {mayor} y el tipo de envío es {posicion}")
    print (f"El porcentaje entero que representa el mayor importe es: {porcentaje}%")

def promedio_envios_menores(vector):
    print("Promedio y envíos menores al promedio")
    
    acumulador = contador_menores = 0
    menor = vector[0]
    
    for i in range (len(vector)):
        acumulador += int(vector[i])
    
    promedio = acumulador // 7
    
    for i in range (len(vector)):
        if vector[i] < promedio:
            contador_menores += 1  
       
    print (f"El importe final promedio es: {promedio}")
    print (f"Cantidad de envíos con importe menor al promedio: {contador_menores}")

def salir():
    print("Salir")

def principal ():
    lista = []
    menu()
    control = "HC"
    vector = None
    opcion = input("Seleccione una opción: ")
    while opcion != "10":
        control, vector = ejecutar_opcion(opcion, lista, control, vector)
        menu() # siempre que elijo una opcion, se ejecuta el menu de opciones de nuevo
        opcion = input("Seleccione una opción: ")
    
if __name__ == "__main__":
    principal()